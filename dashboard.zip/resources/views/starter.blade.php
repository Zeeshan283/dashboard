@extends('layouts.master')
@section('main-content')
<div class="breadcrumb">
                <h1>Blank Page</h1>
                <ul>
                    <li><a href="">UI Kits</a></li>
                    <li>Blank Page</li>
                </ul>

            </div>

            <div class="separator-breadcrumb border-top"></div>
            {{-- end of breadcrumb --}}

@endsection
