<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductContactController extends Controller
{
    //
}
